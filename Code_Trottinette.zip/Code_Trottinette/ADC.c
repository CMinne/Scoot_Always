/*
 * ADC.c
 *
 * Created: 11/10/2018 13:34:55
 *  Author: charl
 */ 
//INCLUDE
#include <avr/io.h>
#include "ADC.h"




//DECLARATION DES VARIABLES GLOGALES


//PROTOTYPE FONCTIONS INTERNES


//CONTENU FONCTIONS EXTERNES

void ADC_init(void)
{
	//Start Single conversion
	ADCSRA|=(1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);
}
int ReadADC(uint8_t ch)
{
	
	//Select ADC Channel ch must be 0-7
	ch=ch&0b01000111;
	ADMUX|=ch|(1<<REFS0);
	ADCSRA|=(1<<ADSC);
	
	while(!(ADCSRA & (1<<ADIF)))
	{
	
	};

	//Clear ADIF by writing one to it
	ADCSRA|=(1<<ADIF);
	return ADC;
}


//CONTENU FONCTIONS INTERNES
