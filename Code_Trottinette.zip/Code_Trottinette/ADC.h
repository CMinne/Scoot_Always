/*
 * ADC.h
 *
 * Created: 11/10/2018 13:35:17
 *  Author: charl
 */ 


#ifndef ADC_H_
#define ADC_H_

//DEFINE


//PROTOTYPE FONCTIONS EXTERNES

void ADC_init(void);
int ReadADC(uint8_t);



#endif /* ADC_H_ */