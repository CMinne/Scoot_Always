/*
 * Callbacks.c
 *
 * Created: 18-02-19 20:50:02
 *  Author: charl
 */


#include <avr/io.h>
#include <avr/interrupt.h>

#include "Callbacks.h"
#include "TIMERS.h"
#include "Main.h"
#include "USART.h"
#include <stdlib.h>

// VARIABLES GLOBALES
unsigned char tmp_int; // pour l'interruption du timer
// VARIABLES POUR CALLBACKS TIMER
void (*My_CB[MAX_CALLBACKS])(void);
void (*My_CB_USART)(volatile char*);
void (*My_Button)(char);
unsigned int Time_CB[MAX_CALLBACKS];
unsigned int TICK_CB[MAX_CALLBACKS];

char buffer [MAX_BUFFER];
volatile int rpmcount = 0;



// DECLARATION DES FONCTIONS INTERNES


// CONTENU DES FONCTIONS EXTERNES
void Callbacks_Init(void)
{
	unsigned char i ;
	// INITIALISATION POUR VARIABLES CALLBACKS TIMER
	for (i = 0 ; i < MAX_CALLBACKS; i++)
	{
		My_CB[i] = 0;
		Time_CB[i] = 0; // Pas obligatoire
	}
	// INITIALISATION DU LCD
	// CONFIGURATION USART POUR INTERRUPTION RD
}
// ENREGISTREMENT CALLBACKS TIMER
unsigned char Callbacks_Record_Timer(void(*pt_Function)(void), unsigned int Time)
{
	unsigned int i = 0;
	while (My_CB[i] != 0 && i < MAX_CALLBACKS) i++;
	if (i < MAX_CALLBACKS)
	{
		My_CB[i] = pt_Function;
		Time_CB[i] = Time;
		TICK_CB[i]= 0;
		return i;
	}
	// IL N�Y A PLUS DE PLACE POUR ENREGISTRER UN CALLBACK
	else return 255;
}

// RETIRER FONCTION DE RAPPEL
void Callbacks_Remove_Timer(unsigned char ID_CB)
{
	if (ID_CB >= 0 && ID_CB < MAX_CALLBACKS);
	{
		My_CB[ID_CB] = 0;
		Time_CB[ID_CB] = 0;
	}
}

// BOUCLE PRINCIPALE DE L�OS
void callbacks_Start(void)
{
	unsigned char idx;
	// INITIALISATION DE TOUTES LES INTERRUPTIONS
	/* initialise Interruptions */
	TIMER0_Init_1ms() ;
	
	// CONFIGURATION TIMER
	sei();
	// BOUCLE INFINIE
	while (1)
	{

		// CHECK LES CONDITIONS POUR RAPPELER LES FONCTIONS LIEES AUTEMPS
		for (idx = 0 ; idx < MAX_CALLBACKS; idx++)
		{
			if (My_CB[idx])if (TICK_CB[idx] >= Time_CB[idx])
			{
				TICK_CB[idx] = 0;
				My_CB[idx]();
			}
		}
	}
}
// CONTENU DES FONCTIONS INTERNES
// INTERRUPTIONS

// INTERRUPTION TIMER

//Interruption TIMER1
ISR(TIMER1_OVF_vect)
{
	// Valeur initiale du compteur = 256 - 125 = 131
	//TCNT0 = 131;
	TCNT1H = 0xFC;
	TCNT1L = 0x17;
	for ( tmp_int = 0 ; tmp_int < MAX_CALLBACKS; tmp_int++)
	{
		 TICK_CB[tmp_int]++;
	}

}
ISR(TIMER0_OVF_vect)
{
	// Valeur initiale du compteur = 256 - 125 = 131
	//TCNT0 = 131;
	TCNT0 = 125;
	for ( tmp_int = 0 ; tmp_int < MAX_CALLBACKS; tmp_int++)
	{
		TICK_CB[tmp_int]++;
	}

}

// Interruption sur la reception en USART

ISR(INT0_vect){
	
	rpmcount++;
}

ISR(PCINT1_vect)						//Interruption Touches
{
	// TESTER	PINC
	char comp_PINB = ~PINC;
	
	//PUSH TEST
	if (comp_PINB & (1<<PINC1))
	{
		PORTD^=(1<<PD7);
		if (REG_EN==1 && Commande<20)
		{
			Commande++;
			//itoa(Commande,buffer,10);
			//Usart_Tx_String(buffer);
		}
	}
	else if (comp_PINB & (1<<PINC2))
	{
		if (REG_EN==1 && Commande>0)
		{
			Commande--;
			//itoa(Commande,buffer,10);
			//Usart_Tx_String(buffer);
		}
	}
	else if (comp_PINB & (1<<PINC3))
	{
		if ( REG_EN==1)
		{
			REG_EN=0;
		}
		else
		{
			REG_EN=1;
			//itoa(REG_EN,buffer,10);
			//Usart_Tx_String(buffer);
		}
	}
	else if (comp_PINB & (1<<PINC4))
	{
		
	}
}