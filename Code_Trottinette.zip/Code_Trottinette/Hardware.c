/*
 * Hardware.c
 *
 * Created: 18-02-19 20:51:12
 *  Author: charl
 */

#include <avr/io.h>
#include <stdlib.h>
#include "Hardware.h"
#include "Main.h"

void hardware_Init(void) 
{
	// INITISALISATION
	
	DDRD |=(1<<DDD1)|(1<<DDD7);								// OUTPUT
	DDRC=(0<<DDC5);
	PORTC|=(0<<PC0)|(0<<PC5);		
									// INPUT

	
	// INTERRUPTION
	EICRA |= (1<<ISC01)|(1<<ISC00);							// Interruption sur flanc montant de INT0
	EIMSK |= (1<<INT0);										// Activation de l'interruption sur INT0
	
	// TOUCHES INC_SPEED (PB0),DEC_SPEED (PB1), REG_EN_DIS (PB2),  (PB3)
	//Input Mode
	CLR_BIT(DDRC,DDC1);
	CLR_BIT(DDRC,DDC2);
	CLR_BIT(DDRC,DDC3);
	CLR_BIT(DDRC,DDC4);
	//enable pull up
	SET_BIT(PORTC,PC1);
	SET_BIT(PORTC,PC2);
	SET_BIT(PORTC,PC3);
	SET_BIT(PORTC,PC4);
	// enable int
	SET_BIT(PCICR,PCIE1);
	// enable mask
	SET_BIT(PCMSK1,PCINT9);  // INC_SPEED
	SET_BIT(PCMSK1,PCINT10);  // DEC_SPEED
	SET_BIT(PCMSK1,PCINT11);  // REG_EN_DIS
	SET_BIT(PCMSK1,PCINT12);  // 
	
}