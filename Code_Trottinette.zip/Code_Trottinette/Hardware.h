/*
 * Hardware.h
 *
 * Created: 17-02-17 23:31:51
 *  Author: laure
 */ 


#ifndef HARDWARE_H_
#define HARDWARE_H_

void hardware_Init(void);



#endif /* HARDWARE_H_ */