// Main.h

#ifndef _main_h_
#define _main_h_

// DEFINE 
// Fr�quence �C
#define _8MHZ

// Gestion registre par bit unique
#define SET_BIT(port,bit)  (port |= (1<<bit))   //set bit in port
#define CLR_BIT(port,bit)  (port &= ~(1<<bit))  //clear bit in port
#define TOGGLE_IO(port,bit) (port = (1<<bit))   //toggle


#define TRUE				1
#define FALSE				0


void Interrupt_Speed(void);
void Blink_Led(void);
void Regulation(void);
#endif /* _main.h */
