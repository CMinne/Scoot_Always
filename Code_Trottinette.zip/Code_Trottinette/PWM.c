#include <avr/io.h>
#include <avr/interrupt.h>
#include "PWM.h"
#include "Main.h"


//Change le dutyCycle du PWM_1A
void setDutyCycle_1A(int Duty_cycle)
{
	//re�oit le duty cycle, valeur de 0 � 10000;
	if((Duty_cycle < ICR1) && (Duty_cycle > 0))
	{
		OCR1A = Duty_cycle;
	}
	else if(Duty_cycle >= ICR1)
	{
		OCR1A = ICR1;
	}
	else
	{
		OCR1A = 0;
	}
}

//Initialisation du PWM_1
void PWM_1_A_B_init(unsigned char Prescaler, unsigned int Top_1)
{
	unsigned char Tampon;
	// PWM1A sur PB1, Output Mode
	SET_BIT(DDRB,DDB1);
	//set OC1B, OC1A on compare match, clear on BOTTOM
	TCCR1A  |= ((1 << COM1A1) | (1 << WGM11)| (0 << WGM10));
	//fast PWM
	TCCR1B |=  (1 << WGM13)| (1 << WGM12);
	//S�lection du prescaler (il s'agit des 3 bits LSB du registre TCCR1B --> pas de shift, uniquement un 'ou' avec le nombre
	//apr�s masquage !)
	Tampon = TCCR1B & 0B11111000;
	TCCR1B = Tampon | Prescaler;
	ICR1 = Top_1; //overflow tous les Top_1 ticks 
	OCR1A = 0;
}






