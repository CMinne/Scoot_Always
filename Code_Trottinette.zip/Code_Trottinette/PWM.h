
#ifndef PWM_H_
#define PWM_H_

//Change le dutyCycle du PWM_1A
void setDutyCycle_1A(int Duty_cycle);
//Initialisation du PWM_1
void PWM_1_A_B_init(unsigned char Prescaler, unsigned int Top_1);

#endif /* PWM_H_ */