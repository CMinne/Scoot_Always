/*
 * TIMERS.c
 *
 * Created: 18-02-19 20:54:22
 *  Author: charl
 */

//FONCTIONS TIMER0


//INCLUDE
#include <avr/io.h>
#include <avr/interrupt.h>

#include "TIMERS.h"
#include "Main.h"



//DECLARATION DES VARIABLES GLOGALES


//PROTOTYPE FONCTIONS INTERNES


//CONTENU FONCTIONS EXTERNES


void TIMER0_Init_1ms(void)
{
	// fr�quence horloge = 1000000 hz
	// Utilisation du TIMER 0, comptage sur 8 bits
	// Si diviseur par 8 --> 1000000/8 = 125 Khz
	// Une p�riode = 8�S
	// Si je compte jusque 125 --> 125 X 8 = 1 ms
	
	CLR_BIT(TCCR0B,CS02);
	SET_BIT(TCCR0B,CS01);
	SET_BIT(TCCR0B,CS00);
	
	// Valeur initiale du compteur = 256 - 125 = 131
	TCNT0 = 125;
	// Autorisation de l'interruption en cas d'overflow
	//TIMSK0 = (1<<TOIE0);
	SET_BIT(TIMSK0,TOIE0);
}

void TIMER1_Init_1ms(void)
{
	//En mode compteur le registre TCCR1A = 0x00
	//Si diviseur par 1 -> 8000000/8 = 1000 Khz
	// Une p�riode = 1�S
	// Si je compte jusque 1000 --> 1000 X 1 = 1 ms
	
	
	// MODE OVERFLOW
	// (TCCR1B) : WGM13 =0 |WGM12 = 0  (TCCR1A) : WGM11 = 0 | WGM10 =0
	CLR_BIT(TCCR1B, WGM13);
	CLR_BIT(TCCR1B, WGM12);
	CLR_BIT(TCCR1A, WGM11);
	CLR_BIT(TCCR1A, WGM10);
	
	//No prescaler
	// (TCCR1B) : CS12 = 0 | CS11 = 1 | CS10 = 0
	CLR_BIT(TCCR1B, CS12);
	SET_BIT(TCCR1B, CS11);
	CLR_BIT(TCCR1B, CS10);
	
	// Valeur initiale du compteur = 65536 - 1000 = 64536
	TCNT1H = 0xFC;
	TCNT1L = 0x17;
	// Autorisation de l'interruption en cas d'overflow
	TIMSK1 |= (1<<TOIE1);
}


//CONTENU FONCTIONS INTERNES
