// TIMERS.h

#ifndef _TIMERS_H_
#define _TIMERS_H_


//DEFINE


//PROTOTYPE FONCTIONS EXTERNES
void TIMER0_Init_1ms(void);
void TIMER1_Init_1ms(void);




#endif /* _TIMERS_H */
