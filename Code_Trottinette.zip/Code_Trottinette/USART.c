/*
 * USART.c
 *
 * Created: 18-02-19 20:52:57
 *  Author: charl
 */

//FONCTIONS USART


//INCLUDE
#include "USART.h"
#include "Main.h"
#include "TIMERS.h"

#include <avr/io.h>
#include <avr/interrupt.h>


//DECLARATION DES VARIABLES GLOGALES
int i=0;
//PROTOTYPE FONCTIONS INTERNES


//CONTENU FONCTIONS EXTERNES

void Usart_Tx(char data)
{
	// UDRE Flag , is the transmit buffer UDR) ready to receive new data ?
	// if UDRE0 =1 the buffer is empty
	while (!(UCSR0A & (1<<UDRE0)));
	UDR0 = data;
}

void Usart_Tx_String(char *String)
{
	char Continue = TRUE;
	while (Continue)
	{
		if(*String==0) Continue = FALSE;
		else Usart_Tx(*String++);
	}
}

void USART_Init_9600(void)
{
	// fr�quence horloge = 1000000 hz, Si Baudrate = 9600 alors UBRR = 12
	//1xspeed  U2X0 = 1
	UCSR0A |= (1<<U2X0);
	// 9600 baud
	//UBRR0 = 12;
	UBRR0H = 0x00;
	UBRR0L = 0x08;
	// Configuration en �mission seulement.
	//(UCSR0B) RXCIE0 = 0 | TXCIE0 =0 | UDRIE0 = 0 | RXEN0 =0 | TXEN0 = 1 | UCSZ02 = 0 | RXB80 = 0 | TXB80 = 0
	UCSR0B = 0b00001000;
	
	// Async. mode, 8 bits, 1 bit de stop, pas de contr�le de parit�
	//(UCSR0C) UMSEL01 = 0 | UMSEL00 = 0 | UPM01 = 1 | UPM00 = 0 | USBS0 = 0 | UCSZ01 = 1 | UCSZ00 = 1 | UCPOL0 = 0;
	UCSR0C|=(1<<UPM01);
	/*
	UBRR0L=0b00001100; //Baudrate = 9600bps
	UBRR0H=0b00000000;
	UCSR0A = 0b00100010; //receiver is ready to receive data, double speed
	UCSR0B = 0b10011000; //Activation de l'�metteur et activation de l'interruption sur la reception USART
	UCSR0C = 0b00000110; //Mode asynchrone, pas de bit de parit�, 1 bit de stop, 8 bits de donn�es*/
}


//CONTENU FONCTIONS INTERNES
