// USART.h

#ifndef _USART_H_
#define _USART_H_


//DEFINE


//PROTOTYPE FONCTIONS EXTERNES

void USART_Init_9600(void);
void Usart_Tx(char data);
void Usart_Tx_String(char *String);

#endif /* _USART_H */