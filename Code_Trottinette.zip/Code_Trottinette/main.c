/*
 * main.c
 *
 * Created: 18-02-19 20:49:10
 *  Author: charl
 */

// Capteur de vitesse (Effet Hall)

// INCLUDE
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <string.h>
#include "Main.h"
#include "TIMERS.h"
#include "USART.h"
#include "Callbacks.h"
#include "Hardware.h"
#include "ftoa.h"
#include "PWM.h"
#include "ADC.h"

//****************** fonction principale *****************
// VARIABLES GLOBALES
unsigned char ID_Interrupt_Speed=0,ID_LED=0,ID_REG=0;
extern volatile int rpmcount;
int rpm = 0;												// Rotation par minute
float speed = 0;											// Vitesse du v�hicule (Km/h)
float buffer1=0,buffer2=0,buffer3=0,buffer4=0;
float d = 14;												// Diametre de la roue (cm)
float average=0;											// Moyenne
float average_copy=0;
char String_RPM[15],String_KMH[15],Buffer[20];  
float buffer_PWM;
volatile unsigned int i,j=0;
unsigned int Throttle_10bit=0;

// Variables PID
float Te=0.25;											// P�riode �chantillonnage (s)
float Consigne = 40;									// Consigne (float)
long int Consigne_Int=0;								// Consigne (int)
long int Process_Out = 0;								// Valeur en sortie du Processus (int)
unsigned int Process_Out_Num = 0;						// Valeur en sortie du Processus (unsigned int)
float Process_In = 0;									// Valeur de la commande (float)
unsigned int Process_In_Num = 0;						// Valeur de la commande (unsigned int)
float Kp = 0.1196;										// Gain (float)
int Kp_Int=0;											// Gain (int)
float Ti = 1.113;										// Constante de temps int�grale en s
float Td = 0;											// Constante de temps d�riv�e en s
long int Epsilon = 0;									// Diff�rence entre la consigne et la sortie du processus
long int Epsilon_Before = 0;							// Idem mais celle une p�riode d'�chantillonnage avant.
long int Regulateur_Out_P = 0;							// Partie Proportionnelle du PID
long int Regulateur_Out_I = 0;							// Partie Int�grale du PID
long int Regulateur_Out_I_Before = 0;					// Idem mais celle une p�riode d'�chantillonnage avant.
long int Terme_Integral = 0;							// Terme de la partie integrale a memoriser
long int Terme_Integral_Before = 0;						// Idem mais celle une periode d'echantillonnage avant
long int Regulateur_Out_D = 0;							// Partie D�riv�e du PID
long int Regulateur_OUT_D_Before = 0;					// Idem mais celle une p�riode d'�chantillonnage avant.
long int K_integrator = 0;								// Constante Te/Ti calculee une seule fois au d?marrage
long int K_derivator = 0;								// Constante Td/(Td+N*Te) calcul�e une seule fois au d?marrage
unsigned int N = 10;									// Coefficient utilis� pour le filtrage du PID
long int K_ARW = 0;										// Gain pour Anti-Windup
float Ratio_Ti_K_ARW = 3;								// 2 du gain du terme int�gral
unsigned char AWU=FALSE;									// Bit Anti-Windup
unsigned char Integral_Saturation =  TRUE;				// Bit Saturation (M�thode 3)
unsigned char Command_Saturation = FALSE;				// Bit Saturation (M�thode 5)
int Saturation_Gravity = 0;								// Voltage_Max-Commande


// FONCTION PRINCIPALE
int main(void)
{
	// INITIALISATION HARDWARE
	hardware_Init() ;
	
	// CONFIGURATION USART
	USART_Init_9600();
	
	// INITIALISATION CALLBACKS
	Callbacks_Init() ;
	
	// INITIALISATION PWM
	PWM_1_A_B_init(0b010,4095);
	//setDutyCycle_1A(1000);
	
	// INITIALISATION ADC
	ADC_init();
	
	// APPEL CALLBACK
	ID_Interrupt_Speed = Callbacks_Record_Timer(Interrupt_Speed, 250);
	ID_LED = Callbacks_Record_Timer(Blink_Led,500);
	ID_REG = Callbacks_Record_Timer(Regulation,Te*1000);
	
	// PRESETTING POUR LE PID
	if (Ti ==0)										// Permet d'annuler l'int�grateur si on veut
	{
		K_integrator = 0;
	}
	else
	{
		K_integrator = (Te/Ti)*1000;				// M�thode pour �viter le probl�me du (Te/Ti)<<<<1
	}
	K_derivator = (Td/(Td + N*Te))*1000;			// Partie D�rivateur
	K_ARW = ((Ratio_Ti_K_ARW*1000000)/Ti);			// Anti-Windup (m�thode 5) (Ratio_Ti_K_ARW petit donc multipli� par 10^6)
	Kp_Int=Kp*1000;									// Float-> Int
	
	// BOUCLE INFINIE
	callbacks_Start();
	
	
	// N�ARRIVE JAMAIS ICI
}
// CONTENU DES FONCTIONS CALLBACKS
void Blink_Led(void)
{
	//PORTD^=(1<<PD7);
}
void Throttle(void)
{
	Throttle_10bit = ReadADC(7);
	setDutyCycle_1A(Throttle_10bit);
	
}
void Interrupt_Speed(void)
{
	EIMSK = (0<<INT0);										// D�sactivation des interruptions le temps du calcul (Le calcul doit �tre rapide)
	
	rpm = rpmcount*60;										// Convertit les rotations par secondes en rotations par minute
	speed = rpm*0.001885*d;									// Formule pour passer de rotation par minute � km/h									
	
	for(i=0;i<5;i++)										// Vide String_KMH
	{
		String_KMH[i]=0;
	}
	
	average = (buffer1+buffer2+buffer3+buffer4+speed)/5;	// Addition pour moyenner la vitesse
	average_copy=average;
	buffer4=buffer3;
	buffer3=buffer2;
	buffer2=buffer1;
	buffer1=speed;
	My_ftoa (average, String_KMH, 1, 'f');
	if(average<10)
	{
		strcpy(Buffer,"0");
		strcat(Buffer,String_KMH);
		strcpy(String_KMH,Buffer);
	}
	char comp_PINC = ~PINC;								// Check si le bit de mesure est actif ou pas (Evite de saturer le buffer USART de la RP
	//PUSH TEST
	if (!(comp_PINC & (1<<PINC0)))
	{
		Usart_Tx_String(String_KMH);					// Si bit � 1, envoi sur l'USART
	}
	average=0;											// Reset
	rpmcount = 0;										// Reset
	
	EIMSK |= (1<<INT0);									// Activation des interruptions
}
void Regulation(void)
{
	char comp_PIND = ~PIND;	
	if (REG_EN==0 && (comp_PIND & (1<<PIND6)))
	{
		Throttle_10bit = ReadADC(5);
		setDutyCycle_1A(1.1*4*Throttle_10bit);
	}
	else
	{
		if(REG_EN==1 && (comp_PIND & (1<<PIND6))) //Detection 0V
		{
			// DEBUT CALCUL REGULATION
			Process_Out=average_copy*1000;
			Epsilon=Commande*1000-Process_Out;
			Regulateur_Out_P=Epsilon;
			Terme_Integral = Terme_Integral_Before + Epsilon;
			Regulateur_Out_I = (K_integrator*Terme_Integral)/1000;
			Process_In=(Kp_Int*(Regulateur_Out_P+Regulateur_Out_I+Regulateur_Out_D))/1000;
			Process_In=Process_In/1000;
			
			// SATURATION
			if ((Process_In >= 0) && (Process_In <= 5))
			{
				Process_In_Num = Process_In * 4095/5;			// Temperature -> Bit
			}
			else if (Process_In < 0)
			{
				Saturation_Gravity = (0 - Process_In);			// Calcul apres - avant la saturation
				Process_In = 0;
				Process_In_Num = 0;
				Command_Saturation = TRUE;

			}
			else // Command > V_MAX
			{
				Saturation_Gravity = (5 - Process_In);			// Calcul apres - avant la saturation
				Process_In = 5;
				Process_In_Num = 4095;
				Command_Saturation = TRUE;
			}
			
			// T-1 = T
			Epsilon_Before=Epsilon;
			
			//ANTI WINDUP
			if(Integral_Saturation)
			{
				if(!Command_Saturation)
				{
					Terme_Integral_Before = Terme_Integral;
				}
			}
			else
			{
				Terme_Integral_Before = Terme_Integral;
			}
			
			
			//SET SORTIE
			setDutyCycle_1A(Process_In_Num);
			// RESET SATURATION
			Command_Saturation=FALSE;
		}
		else if (!(comp_PIND & (1<<PIND6)))
		{
			setDutyCycle_1A(0);
			Commande=0;
		}
	}
	
}